//
//  MenuViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/24/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class MenuViewController: BaseViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Add the childViews to Slide Menu
        
        addChildView(storyBoardID: "HomeScreen", titleOfChildren: "Home", iconName: "Home-1")
        
        addChildView(storyBoardID: "DailyTasks", titleOfChildren: "Daily Tasks", iconName: "dailyTasks")
        
        addChildView(storyBoardID: "CheckedTasksScreen", titleOfChildren: "Checked Tasks", iconName: "checkedTasks")
        
        addChildView(storyBoardID: "Logout", titleOfChildren: "Logout", iconName: "logout")
    
        showFirstChild()
    }
}
