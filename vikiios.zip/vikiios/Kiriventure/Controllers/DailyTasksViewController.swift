//
//  DailyTasksViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/24/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Firebase
import CarbonKit

class DailyTasksViewController: ChildViewController , CarbonTabSwipeNavigationDelegate {
    
    var ref: DatabaseReference!
    var departmentId: String!
    var flowNameId: String!
    
    var users = [User]()
    var items = [String]() // stored flow name in tapbar
    var id = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userData()
    }
    
    func userData() {

        let uid = Auth.auth().currentUser?.email
        let user = User()
        
        // get user detail info from "Users" based on email
        ref = Database.database().reference().child("Users")
        ref.queryOrdered(byChild: "email").queryEqual(toValue: uid!).observe(.childAdded, with: {(snapshot) in

            let dictionary = snapshot.value as? [String: AnyObject]
                
            user.username = dictionary!["name"] as! String
            user.email = dictionary!["email"] as! String
            user.department = dictionary!["department"] as! String

            self.users.append(user)
            self.departmentId = user.department
            
            // get department flowname base on departmentId for the above query
            let reff = Database.database().reference().child("Flows")
            reff.queryOrdered(byChild: "department").queryEqual(toValue: self.departmentId).observe(.childAdded, with: {(snapshot) in
                
                let snap = snapshot.value as? [String: AnyObject]
                let flowName = snap!["flowName"] as! String
                self.flowNameId = snapshot.key
                self.items.append(flowName)
                self.id.append(self.flowNameId)
                
                //Top bar FlowName navigation
                let carbonTabSwipeNavigation = CarbonTabSwipeNavigation(items: self.items , delegate: self)
                carbonTabSwipeNavigation.insert(intoRootViewController: self)
                
               // carbonTabSwipeNavigation.toolbar.isTranslucent = true;
                carbonTabSwipeNavigation.carbonSegmentedControl?.backgroundColor = UIColor(red: 0, green: 0.563, blue: 0.319, alpha: 1.0)
                carbonTabSwipeNavigation.carbonSegmentedControl?.tintColor = UIColor.white
                carbonTabSwipeNavigation.setTabBarHeight(50.0)
                carbonTabSwipeNavigation.setTabExtraWidth(20.0)
                carbonTabSwipeNavigation.setIndicatorColor(UIColor(red: 0, green: 0.563, blue: 0.319, alpha: 1))
                carbonTabSwipeNavigation.setNormalColor(UIColor.white, font: UIFont(name: "Avenir", size: 18)!)
                carbonTabSwipeNavigation.setSelectedColor(UIColor(red: 0, green: 0.563, blue: 0.319, alpha: 1.0), font: UIFont(name: "Avenir", size: 18)!)
            })
        })
    }
    // function to display the content of each tab bar
    func carbonTabSwipeNavigation(_ carbonTabSwipeNavigation: CarbonTabSwipeNavigation, viewControllerAt index: UInt) -> UIViewController {
    
        let taskLists = self.storyboard?.instantiateViewController(withIdentifier: "TabBar") as! TabBarViewController
        
        taskLists.flowId = flowNameId
        
        return taskLists
    }

    private func carbonTabSwipeNavigation(_
        carbonTabSwipeNavigation: CarbonTabSwipeNavigation, didMoveAt index: UInt) -> UIViewController {
        print("Did move at index: %ld", index)
        
        let tabId = self.storyboard?.instantiateViewController(withIdentifier: "TabBar") as! TabBarViewController
        tabId.index = index
        
        return tabId
    }
}
