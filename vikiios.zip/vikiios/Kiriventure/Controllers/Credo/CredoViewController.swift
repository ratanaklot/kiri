//
//  CredoViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/18/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class CredoViewController: UIViewController, UICollectionViewDataSource, UIScrollViewDelegate, UICollectionViewDelegate  {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    var ref: DatabaseReference!

    var credoItem = [String]()
    let cellScaling: CGFloat = 0.8
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView?.dataSource = self
        view.bringSubview(toFront: pageControl)
        handleConnectionIndicator()
        getCredo()
    }
    
    
    
  /*  private func credoCellStyle() {
        let screenSize = UIScreen.main.bounds.size
        let cellWidth = floor(screenSize.width * cellScaling)
        let cellHeight = floor(screenSize.height * cellScaling)
        let layout = collectionView!.collectionViewLayout as! UICollectionViewFlowLayout
        let insetX = (view.bounds.width - cellWidth)/2.0
        let insetY = (view.bounds.height - cellHeight)/2.0

        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        collectionView?.contentInset = UIEdgeInsets(top: insetY, left: insetX, bottom: insetY, right: insetX)
        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
    }*/
    
    func getCredo() {
        let credo = Credo()
        ref = Database.database().reference().child("Credos")
        ref.queryOrdered(byChild: "isActive").queryEqual(toValue: true).observe(.childAdded, with: {(snapshot) in
            if let CredoData = snapshot.value as? [String: AnyObject] {
                credo.credoName = CredoData["name"] as! String
                credo.isActive = CredoData["isActive"] as! Bool
                self.credoItem.append(credo.credoName)
                self.collectionView?.reloadData()
            }
        })
    }
    
    func handleConnectionIndicator() {
        let activityIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 150, height: 100))
        view.addSubview(activityIndicator)
        activityIndicator.frame = view.bounds
        activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.whiteLarge
        
        let connectedRef = Database.database().reference(withPath: ".info/connected")
        connectedRef.observe(.value, with: { snapshot in
            if let connected = snapshot.value as? Bool, connected {
                activityIndicator.removeFromSuperview()
            } else {
                activityIndicator.startAnimating()
            }
        })
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return credoItem.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let credoCell = collectionView.dequeueReusableCell(withReuseIdentifier: "credoCell", for: indexPath) as! CredoCell
        credoCell.credoLabel.text = credoItem[indexPath.item]
        let last = credoItem.last
        if credoItem[indexPath.item] != last {
            credoCell.startNow.isHidden = true
        }
        else {
            credoCell.startNow.isHidden = false
            credoCell.startNow.addTarget(self, action: #selector(CredoViewController.startNowPressed), for: .touchUpInside )
        }
        return credoCell
    }
    // perform segue when "Start Now" pressed
    @objc func startNowPressed(sender: UIButton) {
        self.performSegue(withIdentifier: "goToHome", sender: self)
    }
    // handel page control indicator
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let index = round(scrollView.contentOffset.x / view.frame.width)
        
        pageControl.currentPage = Int(index)
       
        pageControl.numberOfPages = credoItem.count
    }
    // handel position of each cells
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let layout = collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        var offset = targetContentOffset.pointee
        let index = ((offset.x + 1) + scrollView.contentInset.left) / cellWidthIncludingSpacing
        let roundIndex = round(index)
        offset = CGPoint(x: roundIndex * cellWidthIncludingSpacing - scrollView.contentInset.left, y: -scrollView.contentInset.top)
        targetContentOffset.pointee = offset
    }
}
