//
//  CredoCell.swift
//  Kiriventure
//
//  Created by KEEN on 6/8/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class CredoCell: UICollectionViewCell {
    
    @IBOutlet weak var credoLabel: UILabel!
    @IBOutlet weak var startNow: UIButton!
    
    
}
