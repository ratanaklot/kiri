//
//  TapBarViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/25/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Foundation
import Firebase
import Cosmos

class TabBarViewController: UIViewController, UICollectionViewDataSource, UIScrollViewDelegate, UICollectionViewDelegate {
    
    var flowId: String!
    var index: UInt!
    var ref: DatabaseReference!
    var tasks = [Tasks]()
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!

    let cellScaling: CGFloat = 0.8
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       /* collectionView?.dataSource = self
        taskCellStyle()*/
        view.bringSubview(toFront: pageControl)
        self.getFlowTasks()
    }
    
    func getFlowTasks() {
        ref = Database.database().reference().child("Tasks")
        ref.queryOrdered(byChild: "flow").queryEqual(toValue: flowId).observe(.childAdded, with: {(snapshot)in
            
            let snap = snapshot.value as? [String: AnyObject]
            let task = Tasks(taskId: snapshot.key, taskName: snap!["name"]! as! String, flowId: snap!["flow"]! as! String, departmentId: snap!["department"]! as! String)
            self.tasks.append(task)
            print(task.taskName)
            self.collectionView?.reloadData()
        })
    }
    
   /* private func taskCellStyle() {
        let screenSize = UIScreen.main.bounds.size
        let cellWidth = floor(screenSize.width * cellScaling)
        let cellHeight = floor(screenSize.height * cellScaling)
        let insetX = (view.bounds.width - cellWidth)/2.0
        let insetY = (view.bounds.height - cellHeight)/2.0
        let layout = collectionView!.collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        collectionView?.contentInset = UIEdgeInsets(top: insetY, left: insetX, bottom: insetY, right: insetX)
    }*/
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TasksCell", for: indexPath) as! TaskViewCell
        let task = tasks[indexPath.item]
        cell.labelName.text = task.taskName
        cell.cosmosView.didFinishTouchingCosmos = { rating in
            if rating == 1 {
                cell.ratingText.text = "Poor"
            }
            else if rating == 2 {
                cell.ratingText.text = "Average"
            }
            else if rating == 3 {
                cell.ratingText.text = "Okay"
            }
            else if rating == 4{
                cell.ratingText.text = "Good"
            }
            else if rating == 5{
                cell.ratingText.text = "Great"
            }
            else {
                cell.ratingText.text = nil
            }
        }
        return cell
    }
    
    // handle pageControl
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let index = round(scrollView.contentOffset.x / view.frame.width)
        pageControl.currentPage = Int(index)
        pageControl.numberOfPages = tasks.count
    }
    
    //return cell at center while scrolling
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let layout = collectionView?.collectionViewLayout as! UICollectionViewFlowLayout
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        var offset = targetContentOffset.pointee
        let index = ((offset.x + 1) + scrollView.contentInset.left) / cellWidthIncludingSpacing
        let roundIndex = round(index)
        offset = CGPoint(x: roundIndex * cellWidthIncludingSpacing - scrollView.contentInset.left, y: -scrollView.contentInset.top)
        targetContentOffset.pointee = offset
    }
}
