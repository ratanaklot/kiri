//
//  CheckedTaskViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/24/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class CheckedTaskViewController: ChildViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
