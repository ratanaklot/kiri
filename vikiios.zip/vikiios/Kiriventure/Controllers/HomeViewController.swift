//
//  HomeViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/24/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Dismiss the Home Screen with navigation bar
        self.presentedViewController?.dismiss(animated: true, completion: nil)
        
        //Display Credo Screen when Home is pressed in the slide menu
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let credoView:CredoViewController = storyboard.instantiateViewController(withIdentifier: "Credo") as! CredoViewController
        self.present(credoView, animated: true, completion: nil)
    }
}
