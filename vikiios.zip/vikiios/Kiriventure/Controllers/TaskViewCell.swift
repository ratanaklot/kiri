//
//  TaskViewCell.swift
//  Kiriventure
//
//  Created by KEEN on 6/2/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Cosmos

class TaskViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labelName: UILabel!
    @IBOutlet weak var cosmosView: CosmosView!
    @IBOutlet weak var ratingText: UILabel!
    @IBOutlet weak var checkedBtn: UIButton!
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.borderWidth = 2
        self.layer.borderColor = UIColor(red: 0, green: 0.563, blue: 0.319, alpha: 1.0).cgColor
        self.layer.cornerRadius = 40.0
    }
    
    @IBAction func checkeBtnPressed(_ sender: UIButton) {
        checkedBtn.setTitle("Done", for: .normal)
        cosmosView.settings.updateOnTouch = false
        cosmosView.didFinishTouchingCosmos = { rating in }
    }
}
