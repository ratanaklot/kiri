//
//  LoginViewController.swift
//  Kiriventure
///Users/apple/Desktop/Kiriventure/Kiriventure/AppDelegate.swift
//  Created by Apple on 5/13/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Firebase
import MaterialComponents.MaterialButtons
import MaterialComponents.MaterialButtons_ButtonThemer


class LoginViewController: UIViewController, UITextFieldDelegate {
   
    
    

    @IBOutlet weak var login: MDCButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    let button = MDCButton()
    let buttonScheme = MDCButtonScheme()
    
    var animateDistance = CGFloat()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        emailTextField.delegate = self
        passwordTextField.delegate = self
        button.isUppercaseTitle = true
        button.inkColor = UIColor(red: 0, green: 0.563, blue: 0.319, alpha: 1.0)
        
        MDCTextButtonThemer.applyScheme(buttonScheme, to: button)
        login = button
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        
        
        // Check User authenticated?
        if Auth.auth().currentUser?.uid != nil {
        self.presentScreen()
       } 
    }
    // Dismiss keyboard when touching outside textbox
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    // Modify cursor
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == emailTextField{
            passwordTextField.becomeFirstResponder()
        }else if textField == passwordTextField {
            passwordTextField.resignFirstResponder()
            
        }
        return true
    }
    private func handleConnectionIndicator(onView : UIView) -> UIView {
        let spinnerView = UIView.init(frame: onView.bounds)
        spinnerView.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
        let activityIndicator = UIActivityIndicatorView.init(activityIndicatorStyle: .whiteLarge)
        activityIndicator.center = spinnerView.center
        spinnerView.addSubview(activityIndicator)
        onView.addSubview(spinnerView)
        
        let connectedRef = Database.database().reference(withPath: ".info/connected")
        connectedRef.observe(.value, with: { snapshot in
            if let connected = snapshot.value as? Bool, connected {
                activityIndicator.removeFromSuperview()
            } else {
                activityIndicator.startAnimating()
            }
        })
        return spinnerView
    }
    
    // Login Authentication
    @IBAction func loginBtnPressed(_ sender: UIButton) {
        if let email = emailTextField.text, let password = passwordTextField.text {
            Auth.auth().signIn(withEmail: email, password: password, completion: {(user, error) in
                if let FirebaseError = error {
                    
                    let alertVC = UIAlertController(title: FirebaseError.localizedDescription, message: "", preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "ok", style: .default , handler: nil)
                    alertVC.addAction(defaultAction)
                    
                    self.present(alertVC, animated: true, completion: nil)
                    return
                }
                self.presentScreen()
//                self.handleConnectionIndicator(onView: self.view)
            })
        }
    }
    
    // Show the present screen after login
    func presentScreen(){
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let credoVC: CredoViewController = storyboard.instantiateViewController(withIdentifier: "Credo") as! CredoViewController
        self.present(credoVC, animated: true, completion: nil)
    }
    
 
    
    
    @IBAction func forgotPassword(_ sender: UIButton) {
        
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let forgotPasswordVC: ForgotPasswordViewController = storyboard.instantiateViewController(withIdentifier: "ForgotPassword") as! ForgotPasswordViewController
        self.present(forgotPasswordVC, animated: true, completion: nil)
        
    }
    
    @IBAction func dontHaveAccount(_ sender: UIButton) {
        
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let createAccVC: CreateAccountViewController = storyboard.instantiateViewController(withIdentifier: "don'tHaveAccount") as! CreateAccountViewController
        self.present(createAccVC, animated: true, completion: nil)
        
    }
    
}
