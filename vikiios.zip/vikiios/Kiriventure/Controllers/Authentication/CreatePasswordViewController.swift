//
//  CreatePasswordViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/25/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Firebase

class CreatePasswordViewController: UIViewController, UITextFieldDelegate {

    var emailAdress:String?
    
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordConfirmed: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.passwordTextField.delegate = self
        self.passwordConfirmed.delegate = self
    }

    // Dismiss keyboard when touching outside textbox
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    // Modify cursor
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        if textField == passwordTextField {
            passwordConfirmed.becomeFirstResponder()
        }else if textField == passwordConfirmed {
            passwordConfirmed.resignFirstResponder()
        }
        return true
    }

    @IBAction func createPressed(_ sender: UIButton) {
        
        var title = ""
        var message = ""
        
        if self.passwordTextField.text == "" || self.passwordConfirmed.text == "" {
            
            title = "Oops!"
            message = "Please fill up your password properly!"
        }
        else if (self.passwordTextField.text?.count)! <= 5 || (self.passwordConfirmed.text?.count)! <= 5 {
            
            title = "Error"
            message = "Password must contain at least 6 charaters!"
        }
        else if self.passwordTextField.text != self.passwordConfirmed.text {
            
            title = "Error!"
            message = "Your Password and Confirm Password doesn't match."
            
        }
        else {
            Auth.auth().createUser(withEmail: emailAdress!, password: passwordConfirmed.text!, completion: { (user, error) in
                
                let alertController = UIAlertController(title: "Sucess!", message: "Your password have been created!", preferredStyle: .alert)
                
                let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(defaultAction)
                
                self.present(alertController, animated: true, completion: nil)
            })
            self.presentScreen()
        }
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func presentScreen() {
        
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let CredoVC: CredoViewController = storyboard.instantiateViewController(withIdentifier: "Credo") as! CredoViewController
        self.present(CredoVC, animated: true, completion: nil)
    }
}
