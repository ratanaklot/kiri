//
//  CreateAccountViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/25/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Firebase

class CreateAccountViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var emailTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.emailTextField.delegate = self
    }
    
    // Dismiss keyboard when touching outside textbox
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func nextPressed(_ sender: UIButton) {
        
        if self.emailTextField.text == "" {
            let alertController = UIAlertController(title: "Oops!", message: "Please enter an email.", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
            
        } else{
            let databaseRef = Database.database().reference().child("Users")
            
            databaseRef.queryOrdered(byChild: "email").queryEqual(toValue: self.emailTextField.text!).observe(.value, with: { snapshot in
                if snapshot.exists(){
                    //User email exist
                    self.presentScreen()
                }
                else{
                    let alertController = UIAlertController(title: "Oops!", message: "Your email is not register yet. Please check with your manager.", preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }                
            })
        }
    }
    
    @IBAction func cancel(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func presentScreen(){
        
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let createPDVC: CreatePasswordViewController = storyboard.instantiateViewController(withIdentifier: "CreatePassword") as! CreatePasswordViewController
        createPDVC.emailAdress = emailTextField.text
        self.present(createPDVC, animated: true, completion: nil)
    }
}
