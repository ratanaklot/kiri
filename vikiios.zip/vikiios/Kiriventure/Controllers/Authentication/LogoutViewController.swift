//
//  LogoutViewController.swift
//  Kiriventure
//
//  Created by KEEN on 5/18/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit
import Firebase

class LogoutViewController: ChildViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up screen after logout
        let storyboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let loggedOut: LoginViewController  = storyboard.instantiateViewController(withIdentifier: "Login") as! LoginViewController
        do{
            try Auth.auth().signOut()
            self.present(loggedOut, animated: true, completion: nil)
        }
        catch{
            print("Error")
        }
    }
}
