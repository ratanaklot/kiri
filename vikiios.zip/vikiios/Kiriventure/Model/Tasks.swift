//
//  Tasks.swift
//  Kiriventure
//
//  Created by KEEN on 6/5/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import Foundation

class Tasks: NSObject {
    
    var taskId: String
    var taskName: String
    var flowId: String
    var departmentId: String
    
    init(taskId :String, taskName: String, flowId: String, departmentId: String) {
        self.taskId = taskId
        self.taskName = taskName
        self.flowId = flowId
        self.departmentId = departmentId
        super.init()
    }
}
