//
//  Credo.swift
//  Kiriventure
//
//  Created by KEEN on 5/31/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class Credo: NSObject {
    
    var credoId: String!
    var credoName: String!
    var isActive: Bool!
    
    
    
}
