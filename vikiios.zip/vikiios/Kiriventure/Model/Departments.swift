//
//  Departments.swift
//  Kiriventure
//
//  Created by KEEN on 6/5/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class Departments: NSObject {
    
    var departmentid: String!
    var departmentName: String!

}
