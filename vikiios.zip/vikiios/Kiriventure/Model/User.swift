//
//  User.swift
//  Kiriventure
//
//  Created by KEEN on 5/31/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class User: NSObject {
    
    var id: String!
    var username: String!
    var email: String!
    var department: String!
    var position: Int!
    
}
