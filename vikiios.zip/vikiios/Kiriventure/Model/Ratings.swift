//
//  Ratings.swift
//  Kiriventure
//
//  Created by KEEN on 6/5/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class Ratings: NSObject {
    
    var ratingId: String!
    var taskName: String!
    var taskId: String!
    var userId: String!
    var username: String!
    var rating: Int!
    var date: Date!

}
