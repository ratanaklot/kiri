//
//  Flows.swift
//  Kiriventure
//
//  Created by KEEN on 6/5/18.
//  Copyright © 2018 A2A. All rights reserved.
//

import UIKit

class Flows: NSObject {
    
    var flowId : String!
    var departmentId: String!
    var flowName: String!

}
